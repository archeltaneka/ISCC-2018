<!-- header block -->
<header class="header">

	<!-- navigation block -->
	<nav class="navigation header__navigation">
		<!-- navigation links elements -->
		<a href="#home" class="navigation__link dot" data-number="1">
			<span>home</span>
		</a>
		<a href="#about" class="navigation__link dot" data-number="2">
			<span>about</span>
		</a>
		<a href="#competition" class="navigation__link dot" data-number="3">
			<span>competition</span>
		</a>
		<a href="#partners" class="navigation__link dot" data-number="4">
			<span>partners</span>
		</a>
	</nav>

</header>