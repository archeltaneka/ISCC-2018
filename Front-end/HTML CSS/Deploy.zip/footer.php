<!-- footer block -->
<footer class="footer">

	<!-- organized by element -->
	<div class="footer__organize">
		<h3 class="subtitle">organized by:</h3>
		<img src="/assets/img/basis_logo.png" class="footer__logo logo">
	</div>

	<!-- partners element -->
	<!-- <div class="footer__partners">
		<h3 class="subtitle">partnered with:</h3>
	</div> -->

</footer>